pkdx- A lightweight Pokedex manager, editor, and creator
Credit to Purukitto for the images and base pokedex.json on Github
Commands:
dexnum  Searches for the corresponding ID number from the dex.
look    Shows an image of the pokemon.
mkimg   Adds an image to the path.
mkpk    Makes a new pokemon.(-g, -v, -t) 
	-g: Auto generates some stats
	-v: Lets you write even more metadata!
	-t: Auto-translates the Pokemon's name into other languages for more metadata!
search  Searches for a specific Pokemon.
svc     Set the default save directory.